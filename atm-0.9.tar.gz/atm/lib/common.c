/* common.c - Common functions */
 
/* Written 1995 by Werner Almesberger, EPFL-LRC */
 

#include <stdlib.h>
#include <sys/types.h>

#include "atmd.h"


void *alloc(size_t size)
{
    void *n;

    n = malloc(size);
    if (n) return n;
    perror("malloc");
    exit(1);
}
