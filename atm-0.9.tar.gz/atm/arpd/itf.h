/* itf.h - IP interface registry */
 
/* Written 1995 by Werner Almesberger, EPFL-LRC */
 

#ifndef ITF_H
#define ITF_H

#include "table.h"

ITF *lookup_itf(int number);
ITF *lookup_itf_by_ip(unsigned long ip);
int itf_create(int number);
void itf_up(int number);
void itf_down(int number);

#endif
