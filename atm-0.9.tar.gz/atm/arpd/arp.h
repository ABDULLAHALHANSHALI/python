/* arp.h - ARP state machine */
 
/* Written 1995 by Werner Almesberger, EPFL-LRC */
 

#ifndef ARP_H
#define ARP_H

#include <linux/atmarp.h>

#include "table.h"


void need_ip(int itf_num,unsigned long ip);
void incoming_arp(VCC *vcc,struct atmarphdr *hdr,int len);
int arp_ioctl(int itf_num,unsigned long cmd,struct atmarpreq *req);
void vcc_connected(VCC *vcc);
void vcc_failed(VCC *vcc);
void disconnect_vcc(VCC *vcc);
void incoming_call(VCC *vcc);

#endif
