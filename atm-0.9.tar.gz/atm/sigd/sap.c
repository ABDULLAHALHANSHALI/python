/* sap.c - SAP manipulations */
 
/* Written 1996 by Werner Almesberger, EPFL-LRC */
 

#include <stdlib.h>
#include <string.h>
#include <linux/atm.h>
#include <linux/atmdev.h>

#include "atm.h"
#include "atmd.h"
#include "q2931.h"
#include "qlib.h"

#include "common.h"
#include "sap.h"


#define COMPONENT "SAP"


/*
 * Packing assumes that sizeof(X) == (char *) &(&X)[1]-(char *) &X
 * for struct sockaddr_atmsvc and struct atm_blli, and that both use
 * compatible alignments.
 */


int sap_check_packing(const struct sockaddr_atmsvc *packed_sap,int len)
{
    if ((len -= sizeof(struct sockaddr_atmsvc)) < 0) return 0;
    if (len % sizeof(struct atm_blli)) return 0;
    return 1;
}


struct sockaddr_atmsvc *sap_copy(const struct sockaddr_atmsvc *sap)
{
    struct sockaddr_atmsvc *new_sap;
    struct atm_blli *walk,**here;
    int size;

    size = sizeof(struct sockaddr_atmsvc);
    for (walk = sap->sas_addr.blli; walk; walk = walk->next)
	size += sizeof(struct atm_blli);
    new_sap = alloc(size);
    memcpy(new_sap,sap,size);
    here = &new_sap->sas_addr.blli;
    for (walk = (struct atm_blli *) (new_sap+1); (char *) walk <
      (char *) new_sap+size; walk++) {
	*here = walk;
	here = &walk->next;
    }
    *here = NULL;
    return new_sap;
}


static int class_compat(const struct atm_trafprm *tx,
  const struct atm_trafprm *rx)
{
    if (tx->class == ATM_NONE) return 1;
    if (rx->class == ATM_UBR) return 1; /* don't apply CAC to PCR */
    if (tx->class != rx->class) return 0;
	/* ignore special cases like CBR to VBR for now */
    switch (tx->class) {
	case ATM_CBR:
	    if (!rx->max_pcr || rx->max_pcr == ATM_MAX_PCR) return 1;
	    return tx->min_pcr <= rx->max_pcr;
	    /* Actually, we shouldn't look at min_pcr, because there's no
	       bandwidth negotiation anyway. */
	default:
	    diag(COMPONENT,DIAG_ERROR,"unsupported traffic class %d\n",
	      tx->class);
	    return 0;
    }
}


static int bhli_compat(const struct atm_bhli *old,const struct atm_bhli *new,
  struct atm_bhli *res)
{
    int length;

    if (res) *res = *new;
    if (!old->hl_type) return 1;
    if (old->hl_type != new->hl_type) return 0;
    switch (old->hl_type) {
	case ATM_HL_ISO:
	case ATM_HL_USER:
	    length = old->hl_length;
	    if (length != new->hl_length) return 0;
	    break;
#ifdef UNI30
	case ATM_HL_HLP:
	    length = 4;
	    break;
#endif
	case ATM_HL_VENDOR:
	    length = 7;
	    break;
	default:
	    length = 0;
    }
    return !length || !memcmp(old->hl_info,new->hl_info,length);
}


static int match_blli(const struct atm_blli *a,const struct atm_blli *b)
{
    if (a->l2_proto != b->l2_proto || a->l3_proto != b->l3_proto) return 0;
    switch (a->l3_proto) {
	case ATM_L3_TR9577:
	    if (a->l3.tr9577.ipi != b->l3.tr9577.ipi) return 0;
	    if (a->l3.tr9577.ipi == NLPID_IEEE802_1_SNAP)
		if (memcmp(a->l3.tr9577.snap,b->l3.tr9577.snap,5)) return 0;
	    break;
        case ATM_L3_USER:
	    if (a->l3.user != b->l3.user) return 0;
	    break;
	default:
    }
    return 1;
}


static int blli_compat(const struct atm_blli *old,const struct atm_blli *new,
   struct atm_blli **ptr,struct atm_blli *res)
{
    if (res)
	if (!new) *ptr = NULL;
	else {
	    *res = *new;
	    *ptr = res;
	}
    if (!old) return 1;
    while (old) {
	while (new) {
	    if (match_blli(old,new)) {
		if (res) *res = *new;
		return 1;
	    }
	    new = new->next;
	}
	old = old->next;
    }
    return 0;
}


static int do_sap_compat(const struct sockaddr_atmsvc *old,
  const struct sockaddr_atmsvc *new,struct sockaddr_atmsvc *res)
{
    if (old->sas_txtp.max_sdu && new->sas_rxtp.max_sdu &&
      old->sas_txtp.max_sdu > new->sas_rxtp.max_sdu) return 0;
    if (new->sas_txtp.max_sdu && old->sas_rxtp.max_sdu &&
      new->sas_txtp.max_sdu > old->sas_rxtp.max_sdu) return 0;
    if (!class_compat(&old->sas_txtp,&new->sas_rxtp) ||
      !class_compat(&new->sas_txtp,&old->sas_rxtp)) return 0;
    if (!bhli_compat(&old->sas_addr.bhli,&new->sas_addr.bhli,
      res ? &res->sas_addr.bhli : NULL)) return 0;
    return blli_compat(old->sas_addr.blli,new->sas_addr.blli,
      res ? &res->sas_addr.blli : NULL,res ? (struct atm_blli *) (res+1) :
      NULL);
}


int sap_compat(const struct sockaddr_atmsvc *old,
  const struct sockaddr_atmsvc *new,struct sockaddr_atmsvc **out)
{
    struct sockaddr_atmsvc *res;
    int compat;

    if ((*old->sas_addr.prv || *old->sas_addr.pub) && !atm_equal(old,new,0,0))
	return 0;
    if (!out) res = NULL;
    else res = alloc(sizeof(struct sockaddr_atmsvc)+sizeof(struct atm_blli));
    compat = do_sap_compat(old,new,res);
    if (out)
	if (!compat) free(res);
	else {
	    *out = res;
	    *res = *new;
	    if (res->sas_addr.blli)
		res->sas_addr.blli = (struct atm_blli *) (res+1);
	}
    return compat;
}


void sap_encode(Q_DSC *dsc,const struct sockaddr_atmsvc *sap)
{
    struct atm_blli *blli;

    if (*sap->sas_addr.prv) /* improve @@@ */
	q_write(dsc,QF_cdpn_esa,(void *) sap->sas_addr.prv,ATM_ESA_LEN);
    switch (sap->sas_txtp.class) {
	case ATM_NONE:
	    break;
	case ATM_UBR:
	    q_assign(dsc,QF_fw_pcr_01,ATM_OC3_PCR);
	    q_assign(dsc,QF_bw_pcr_01,ATM_OC3_PCR);
	    q_assign(dsc,QF_best_effort,0);
	    break;
	case ATM_CBR:
	    q_assign(dsc,QF_fw_pcr_01,sap->sas_txtp.min_pcr);
	    break;
        default:
	    diag(COMPONENT,DIAG_FATAL,"bad TX class (%d)",sap->sas_txtp.class);
    }
    switch (sap->sas_txtp.class == ATM_UBR ? ATM_NONE : sap->sas_rxtp.class) {
	case ATM_NONE:
	    break;
	case ATM_CBR:
	    q_assign(dsc,QF_bw_pcr_01,sap->sas_rxtp.min_pcr);
	    break;
        default:
	    diag(COMPONENT,DIAG_FATAL,"bad RX class (%d)",sap->sas_txtp.class);
    }
    if (sap->sas_txtp.max_sdu)
	q_assign(dsc,QF_fw_max_sdu,sap->sas_txtp.max_sdu);
    if (sap->sas_rxtp.max_sdu)
	q_assign(dsc,QF_bw_max_sdu,sap->sas_rxtp.max_sdu);
    /* @@@ bearer class ? */
    /* @@@ QOS class ? */
    if (sap->sas_addr.bhli.hl_type != ATM_HL_NONE) {
        q_assign(dsc,QF_hli_type,sap->sas_addr.bhli.hl_type);
        switch (sap->sas_addr.bhli.hl_type) {
            case ATM_HL_ISO:
                q_write(dsc,QF_iso_hli,sap->sas_addr.bhli.hl_info,
		  sap->sas_addr.bhli.hl_length);
                break;
            case ATM_HL_USER:
                q_write(dsc,QF_user_hli,sap->sas_addr.bhli.hl_info,
		  sap->sas_addr.bhli.hl_length);
                break;
#ifdef UNI30
            case ATM_HL_HLP:
                q_write(dsc,QF_iso_hli,sap->sas_addr.bhli.hl_info,4);
                break;
#endif
            case ATM_HL_VENDOR:
                q_write(dsc,QF_iso_hli,sap->sas_addr.bhli.hl_info,7);
                break;
            default:
                diag(COMPONENT,DIAG_FATAL,"bad hl_type (%d)",
		  sap->sas_addr.bhli.hl_type);
        }
    }
    for (blli = sap->sas_addr.blli; blli; blli = blli->next) {
	if (blli->l2_proto != ATM_L2_NONE) {
	    q_assign(dsc,QF_uil2_proto,blli->l2_proto);
	    switch (blli->l2_proto) {
		case ATM_L2_X25_LL:
		case ATM_L2_X25_ML:
		case ATM_L2_HDLC_ARM:
		case ATM_L2_HDLC_NRM:
		case ATM_L2_HDLC_ABM:
		case ATM_L2_Q922:
		case ATM_L2_ISO7776:
		    if (blli->l2.itu.mode != ATM_IMD_NONE)
			q_assign(dsc,QF_l2_mode,blli->l2.itu.mode);
		    if (blli->l2.itu.window)
			q_assign(dsc,QF_window_size,blli->l2.itu.window);
		    break;
		case ATM_L2_USER:
		    q_assign(dsc,QF_user_l2,blli->l2.user);
		    break;
		default:
		    break;
	    }
	}
	if (blli->l3_proto != ATM_L3_NONE) {
	    q_assign(dsc,QF_uil3_proto,blli->l3_proto);
	    switch (blli->l3_proto) {
		case ATM_L3_X25:
		case ATM_L3_ISO8208:
		case ATM_L3_X223:
		    if (blli->l3.itu.mode != ATM_IMD_NONE)
			q_assign(dsc,QF_l3_mode,blli->l3.itu.mode);
		    if (blli->l3.itu.def_size)
			q_assign(dsc,QF_def_pck_size,blli->l3.itu.def_size);
		    if (blli->l3.itu.window)
			q_assign(dsc,QF_pck_win_size,blli->l3.itu.window);
		    break;
		case ATM_L3_TR9577:
		    q_assign(dsc,QF_ipi_high,blli->l3.tr9577.ipi >> 1);
		    q_assign(dsc,QF_ipi_low,blli->l3.tr9577.ipi & 1);
		    if (blli->l3.tr9577.ipi == NLPID_IEEE802_1_SNAP) {
			q_write(dsc,QF_oui,blli->l3.tr9577.snap,3);
			q_write(dsc,QF_pid,blli->l3.tr9577.snap+3,2);
		    }
		    break;
		case ATM_L3_USER:
		    q_assign(dsc,QF_user_l3,blli->l3.user);
		    break;
		default:
		    diag(COMPONENT,DIAG_FATAL,"bad l3_proto (%d)",
		      blli->l3_proto);
	    }
	}
	break; /* @@@ allow for repeated BLLI */
    }
}


struct sockaddr_atmsvc *sap_decode(Q_DSC *dsc)
{
    struct sockaddr_atmsvc *sap;
    struct atm_blli *blli;

    sap = alloc(sizeof(struct sockaddr_atmsvc)+sizeof(struct atm_blli));
    blli = (struct atm_blli *) (sap+1);
    memset(sap,0,sizeof(struct sockaddr_atmsvc));
    sap->sas_family = AF_ATMSVC;
    if (q_present(dsc,QF_cdpn_esa)) /* @@@ handle E.164 too */
	(void) q_read(dsc,QF_cdpn_esa,(void *) &sap->sas_addr.prv,ATM_ESA_LEN);
    if (q_present(dsc,QF_aal_type))
	if (q_fetch(dsc,QF_aal_type) != 5)
	    diag(COMPONENT,DIAG_ERROR,"AAL type %d requested",
	      q_fetch(dsc,QF_aal_type));
    if (q_present(dsc,QF_best_effort))
	sap->sas_txtp.class = sap->sas_rxtp.class = ATM_UBR;
    else {
	sap->sas_txtp.class = sap->sas_rxtp.class = ATM_CBR;
	if (q_present(dsc,QF_fw_pcr_01))
	    sap->sas_txtp.min_pcr = sap->sas_txtp.max_pcr =
	      q_fetch(dsc,QF_fw_pcr_01);
	if (q_present(dsc,QF_bw_pcr_01))
	    sap->sas_rxtp.min_pcr = sap->sas_rxtp.max_pcr =
	      q_fetch(dsc,QF_bw_pcr_01);
	/* SHOULD ... fail call if anything is missing ... @@@ */
    }
    if (q_present(dsc,QF_fw_max_sdu))
	sap->sas_txtp.max_sdu = q_fetch(dsc,QF_fw_max_sdu);
    if (q_present(dsc,QF_bw_max_sdu))
	sap->sas_rxtp.max_sdu = q_fetch(dsc,QF_bw_max_sdu);
    if (q_present(dsc,QG_bhli)) {
	sap->sas_addr.bhli.hl_type = q_fetch(dsc,QF_hli_type);
	switch (sap->sas_addr.bhli.hl_type) {
	    case ATM_HL_ISO:
		sap->sas_addr.bhli.hl_length = q_length(dsc,QF_iso_hli);
		q_read(dsc,QF_iso_hli,sap->sas_addr.bhli.hl_info,
		  sap->sas_addr.bhli.hl_length);
		break;
	    case ATM_HL_USER:
		sap->sas_addr.bhli.hl_length = q_length(dsc,QF_user_hli);
		q_read(dsc,QF_user_hli,sap->sas_addr.bhli.hl_info,
		  sap->sas_addr.bhli.hl_length);
		break;
#ifdef UNI30
	    case ATM_HL_HLP:
		sap->sas_addr.bhli.hl_length = 4;
		q_read(dsc,QF_hlp,sap->sas_addr.bhli.hl_info,4);
		break;
#endif
	    case ATM_HL_VENDOR:
		sap->sas_addr.bhli.hl_length = 7;
		q_read(dsc,QF_hli_oui,sap->sas_addr.bhli.hl_info,3);
		q_read(dsc,QF_app_id,sap->sas_addr.bhli.hl_info+3,4);
		break;
	    default:
		diag(COMPONENT,DIAG_FATAL,"unrecognized hl_type");
	}
    }

#define GET(var,field) \
   ({ if (q_present(dsc,field)) blli->var = q_fetch(dsc,field); })

    if (q_present(dsc,QG_blli)) {
	sap->sas_addr.blli = blli;
	if (q_present(dsc,QF_uil2_proto)) {
	    blli->l2_proto = q_fetch(dsc,QF_uil2_proto);
	    GET(l2.itu.mode,QF_l2_mode);
	    GET(l2.itu.window,QF_window_size);
	    GET(l2.user,QF_user_l2);
	}
	if (q_present(dsc,QF_uil3_proto)) {
	    blli->l3_proto = q_fetch(dsc,QF_uil3_proto);
	    GET(l3.itu.mode,QF_l3_mode);
	    GET(l3.itu.def_size,QF_def_pck_size);
	    GET(l3.itu.window,QF_pck_win_size);
	    GET(l3.user,QF_user_l3);
	    if (q_present(dsc,QF_ipi_high)) {
		blli->l3.tr9577.ipi = q_fetch(dsc,QF_ipi_high) << 1;
		if (blli->l3.tr9577.ipi != NLPID_IEEE802_1_SNAP)
		    blli->l3.tr9577.ipi |= q_fetch(dsc,QF_ipi_low);
		else if (!q_present(dsc,QF_oui)) blli->l3.tr9577.ipi |= 1;
		    else {
			q_read(dsc,QF_oui,blli->l3.tr9577.snap,3);
			q_read(dsc,QF_pid,blli->l3.tr9577.snap+3,2);
		    }
	    }
	}
	blli->next = NULL;
    }
#undef GET
    return sap;
}
