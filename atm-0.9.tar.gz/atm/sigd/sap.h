/* sap.h - SAP manipulations */

/* Written 1996 by Werner Almesberger, EPFL-LRC */


#ifndef SAP_H
#define SAP_H

#include <linux/atmsap.h>
#include <linux/atmsvc.h>

int sap_check_packing(const struct sockaddr_atmsvc *packed_sap,int len);
struct sockaddr_atmsvc *sap_copy(const struct sockaddr_atmsvc *sap);
int sap_compat(const struct sockaddr_atmsvc *old,
  const struct sockaddr_atmsvc *new,struct sockaddr_atmsvc **out);
void sap_encode(Q_DSC *dsc,const struct sockaddr_atmsvc *sap);
struct sockaddr_atmsvc *sap_decode(Q_DSC *dsc);

#endif
