/*
 * io.c - Ilmi input/output routines
 *
 * Written by Scott W. Shumate
 * 
 * Copyright (c) 1995 Telecommunications & Information
 * Sciences Laboratory, The University of Kansas 
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify and distribute this
 * software and its documentation is hereby granted,
 * provided that both the copyright notice and this
 * permission notice appear in all copies of the software,
 * derivative works or modified versions, and any portions
 * thereof, that both notices appear in supporting
 * documentation, and that the use of this software is
 * acknowledged in any publications resulting from using
 * the software.
 * 
 * TISL ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS"
 * CONDITION AND DISCLAIMS ANY LIABILITY OF ANY KIND FOR
 * ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS
 * SOFTWARE.
 * 
 * Telecommunications & Information Science Lab
 * 2291, Irving Hill Road Lawrence, KS 66046
 * (913)-864-7757
 * http://www.tisl.ukans.edu
 * 
 * The development of this software was generously
 * supported by research grants from Sprint corporation,
 * and we would like to express our thanks.
 */

#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <linux/if.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/atmarp.h>
#include <linux/atmclip.h>
#include "io.h"
#include "atmd.h"

#define SNMP_VCI 16
#define COMPONENT "IO"


static short atm_itf = -1; /* bad value */


AsnOid *get_esi(int fd)
{
  static AsnOid *name;
  struct atmif_sioc req;
  unsigned char esi[ESI_LEN];
  int m, n, size;

  req.number = 0;
  req.arg = esi;
  req.length = ESI_LEN;

  if(ioctl(fd, ATM_GETESI, &req) < 0)
    diag(COMPONENT, DIAG_FATAL, "ioctl ATM_GETESI: %s", strerror(errno));
  
  /* Convert hex string to Object ID BER */
  for(m = 0, size = 0; m < ESI_LEN; esi[m++] & 0x80 ? size += 2 : size++);
  size++;
  name = alloc_t(AsnOid);
  name->octs = alloc(size);
  name->octetLen = size;
  
  for(m = 0, n = 0; m < ESI_LEN; m++, n++)
    {
      if(esi[m] & 0x80)
	name->octs[n++] = '\201';
      name->octs[n] = esi[m] & 0x7F;
    }
  
  /* Add the SEL */
  name->octs[n] = '\0';

  return name;
}

void delete_nsap(int itf)
{
  struct atmif_sioc req;
  int fd;
  
  if ((fd = socket(AF_ATMSVC, SOCK_DGRAM, 0)) < 0)
    diag(COMPONENT, DIAG_FATAL, "socket: %s", strerror(errno));

  req.number = itf;
  req.arg = NULL;

  if(ioctl(fd, ATM_RSTADDR, &req) < 0)
    diag(COMPONENT, DIAG_FATAL, "ioctl ATM_RSTADDR: %s", strerror(errno));

  close(fd);
}

void add_nsap(int itf, AsnOid *netprefix, AsnOid *esi)
{
  struct atmif_sioc req;
  struct sockaddr_atmsvc addr;
  int fd, m, n;

  addr.sas_family = AF_ATMSVC;
  addr.sas_addr.bhli.hl_type = ATM_HL_NONE;
  addr.sas_addr.blli = NULL;
  addr.sas_addr.pub[0] = 0;
  
  /* Convert net prefix BER to hex */
  for(m = 0, n = 0; m < netprefix->octetLen; m++, n++)
    if(netprefix->octs[m] & 0x80)
      addr.sas_addr.prv[n] = netprefix->octs[++m] | 0x80;
    else
      addr.sas_addr.prv[n] = netprefix->octs[m];

  /* Convert esi BER to hex */
  for(m = 0; m < esi->octetLen; m++, n++)
    if(esi->octs[m] & 0x80)
      addr.sas_addr.prv[n] = esi->octs[++m] | 0x80;
    else
      addr.sas_addr.prv[n] = esi->octs[m];

  if ((fd = socket(AF_ATMSVC, SOCK_DGRAM, 0)) < 0)
    diag(COMPONENT, DIAG_FATAL, "socket: %s", strerror(errno));

  req.number = itf;
  req.arg = &addr;
  req.length = sizeof(addr);

  if(ioctl(fd, ATM_ADDADDR, &req) < 0)
    diag(COMPONENT, DIAG_FATAL, "ioctl ATM_ADDADDR: %s", strerror(errno));

  close(fd);

}

int wait_for_message(int fd, struct timeval *timeout)
{
  int numfds;
  fd_set fdvar;

  FD_ZERO(&fdvar);
  FD_SET(fd, &fdvar);

  if((numfds = select(fd + 1, &fdvar, 0, 0, timeout)) < 0)
    diag(COMPONENT, DIAG_FATAL, "select: %s", strerror(errno));

  return numfds;
}


int read_message(int fd, Message *message)
{
  SBuf buffer;
  char data[MAX_ILMI_MSG];
  AsnLen length;
  jmp_buf env;

  if ((int) (length = read(fd, data, MAX_ILMI_MSG)) < 0)
    diag(COMPONENT, DIAG_FATAL, "read: %s", strerror(errno));

  SBufInstallData(&buffer, data, length);
  if (setjmp(env) == 0)
    {
      BDecMessage(&buffer, message, &length, env);
    }
  else
    {
      diag(COMPONENT, DIAG_ERROR, "message decoding error");
      return -1;
    }
  
  if(message->version != VERSION_1)
    {
      diag(COMPONENT, DIAG_ERROR, "received message with wrong version number");
      return -1;
    }

  if(message->community.octetLen != 4 || 
     memcmp(message->community.octs, "ILMI", 4))
    {
      diag(COMPONENT, DIAG_ERROR, "received message with wrong community");
      return -1;
    }

  return 0;
}

int send_message(int fd, Message *message)
{
  SBuf buffer;
  AsnLen length;
  char data[MAX_ILMI_MSG];

  SBufInit(&buffer, data, MAX_ILMI_MSG);
  SBufResetInWriteRvsMode(&buffer);
  
  if(!(length = BEncMessage(&buffer, message)))
  {
    diag(COMPONENT, DIAG_ERROR, "message encoding error\n");
    return -1;
  }
  
  if(write(fd, SBufDataPtr(&buffer), length) != length)
    diag(COMPONENT, DIAG_FATAL, "write: %s", strerror(errno));
  
  return 0;
}


int open_ilmi(int itf)
{
    struct sockaddr_atmpvc addr;
    int fd;
 
    if((fd = socket(PF_ATMPVC, SOCK_DGRAM, ATM_AAL5)) < 0)
      diag(COMPONENT, DIAG_FATAL, "socket: %s", strerror(errno));

    memset(&addr, 0, sizeof(addr));
    addr.sap_family = AF_ATMPVC;
    addr.sap_addr.itf = itf;
    addr.sap_rxtp.class = ATM_UBR;
    addr.sap_txtp.class = ATM_UBR;
    addr.sap_rxtp.max_sdu = MAX_ILMI_MSG;
    addr.sap_txtp.max_sdu = MAX_ILMI_MSG;
    addr.sap_addr.vpi = 0;
    addr.sap_addr.vci = SNMP_VCI;

    if(bind(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0)
      diag(COMPONENT, DIAG_FATAL, "bind: %s", strerror(errno));

    return fd;
}
