/*
 * netprefix.h - Access routines to the NetPrefix MIB variable
 *
 * Written by Scott W. Shumate
 * 
 * Copyright (c) 1995 Telecommunications & Information
 * Sciences Laboratory, The University of Kansas 
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify and distribute this
 * software and its documentation is hereby granted,
 * provided that both the copyright notice and this
 * permission notice appear in all copies of the software,
 * derivative works or modified versions, and any portions
 * thereof, that both notices appear in supporting
 * documentation, and that the use of this software is
 * acknowledged in any publications resulting from using
 * the software.
 * 
 * TISL ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS"
 * CONDITION AND DISCLAIMS ANY LIABILITY OF ANY KIND FOR
 * ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS
 * SOFTWARE.
 * 
 * Telecommunications & Information Science Lab
 * 2291, Irving Hill Road Lawrence, KS 66046
 * (913)-864-7757
 * http://www.tisl.ukans.edu
 * 
 * The development of this software was generously
 * supported by research grants from Sprint corporation,
 * and we would like to express our thanks.
 */

#ifndef ACCESS_H
#define ACCESS_H

#include "rfc1157_snmp.h"
#include "mib.h"

AsnOid atmNetPrefixStatus;

AsnOid *accessNetPrefix(void);
void deleteNetPrefix(void);
AsnInt getNetPrefix(VarBind *varbind, Variable *var);
AsnInt getnextNetPrefix(VarBind *varbind, Variable *var);
AsnInt setNetPrefix(VarBind *varbind, Variable *var);

#endif
